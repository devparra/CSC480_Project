package com.CS480.hoa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditHomeOwnerActivity extends AppCompatActivity {

    public static final String userCode = "com.CS480.hoa.editHomeOwner";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_home_owner);
    }
}
