package com.CS480.hoa;

public class Test {

    private int status;
    private String message;

    public int getStatus(){return status;}
    public String getMessage(){return message;}
}
