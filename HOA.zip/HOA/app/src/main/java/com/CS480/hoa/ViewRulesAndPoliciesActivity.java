package com.CS480.hoa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewRulesAndPoliciesActivity extends AppCompatActivity {

    public static final String userCode = "com.CS480.hoa.viewRulesAndPolicies";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_rules_and_policies);
    }
}
