package com.CS480.hoa;

public class Admin {
}
